# ROLL CÂY CẢNH iOS R4 — FIX GITHUB ACTIONS

## Quan trọng: upload đúng cấu trúc repository

ZIP này đã được đóng gói với các file dự án ở ngay cấp đầu tiên, không bọc trong thư mục `ROLL_CAY_CANH_iOS_BOOTSTRAP_V26.2.92/`.

Trong repository `ROLL-CAY-CANH-iOS`, các đường dẫn sau phải tồn tại ngay từ thư mục gốc:
- `package.json`
- `web/index.html`
- `web/tiktok-label-import.js`
- `reference/app/src/main/assets/index.html`
- `reference/app/src/main/assets/tiktok-label-import.js`
- `reference/tools/admin_direct_completion_test.js`
- `reference/tools/tiktok_pdf_real_layout_regression_test.js`
- `.github/workflows/ios-build.yml`

Không chỉ tải riêng workflow hoặc chỉ tải thư mục `web/`. Phải upload toàn bộ nội dung trong ZIP vào root repository, giữ nguyên thư mục `.github` và `reference`. Nếu GitHub web trên iPad không cho upload thư mục ẩn `.github`, tạo workflow file thủ công tại `.github/workflows/ios-build.yml` và dán nội dung từ `ios-build.yml` ở root.

## Cách kiểm tra nhanh sau khi upload
Mở repository trên GitHub và kiểm tra các đường dẫn trên đều có thật. Sau đó vào Actions → ROLL CAY CANH iOS Build → Run workflow.

## Kết quả xác minh gói
Chạy `node scripts/validate-workspace.mjs` trên bản source này: 86/86 test nghiệp vụ đạt, preflight đạt, 4/4 inline JavaScript block đạt, Android V26.2.92 reference preflight đạt. Đây chưa phải bằng chứng Xcode build hoặc IPA đã thành công.
